Documentation
===============
See the Users Guide and API documentation hosted at
http://packages.python.org/pyfits.

Development
=============
PyFITS has a Trac site used for development at:
https://trac6.assembla.com/pyfits

All issue numbers mentioned in the changelog (#n) refer to ticket numbers in
Trac.  To report an issue in PyFITS, send an e-mail to help@stsci.edu.

The latest source code can be checked out from SVN with::

 svn checkout https://svn6.assembla.com/svn/pyfits/trunk
